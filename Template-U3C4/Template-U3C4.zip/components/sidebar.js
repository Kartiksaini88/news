function sidebar() {


    // return your html component here
    //Make sure to give input search box id as ""
    return ` <h2>Login</h2>
    <input type="text" id="searchbar" placeholder="Search for an article" >
    <h2>Startups</h2>
    <h2>Newsletters</h2>
    <h2>Audio</h2>
    <h2>Video</h2>`
}
export default sidebar